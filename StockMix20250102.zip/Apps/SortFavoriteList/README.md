# Sort Favorite List for TRIMUI Smart

Sort items in `FAVORITE` list alphabetically.

## Install

Add `SortFavoriteList` folder to `Apps` directory in your microSD card.

## Usage

Select `APP` => `Sort Favorite List` from MainUI menu.
