#!/bin/sh

cd /usr/trimui/res/sound
rm -R click.wav
mv click3.wav click.wav
reboot

