#!/bin/sh

cd /usr/trimui/res/sound

mv bgm-off.mp3 bgm.mp3