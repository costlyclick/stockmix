#!/bin/sh

cd /usr/trimui/res/sound
mv click.wav click3.wav
cp -R /mnt/SDCARD/click.wav /usr/trimui/res/sound
reboot

