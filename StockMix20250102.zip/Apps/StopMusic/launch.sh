#!/bin/sh

cd /usr/trimui/res/sound

mv bgm.mp3 bgm-off.mp3